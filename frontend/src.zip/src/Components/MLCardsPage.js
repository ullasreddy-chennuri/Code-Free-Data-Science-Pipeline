import React, { useState, useRef } from 'react';
import { Button } from '@mui/material';

import { Accordion, AccordionSummary, AccordionDetails, Typography, Card, CardContent } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import '../Styles/MLCardsPage.css';
import Header from './Header';
import ReplayIcon from '@mui/icons-material/Replay';
import { Link } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';


const ModelAccordion = ({ title, description, models, onSelectModel }) => {
  const [expanded, setExpanded] = useState(false);
  const accordionRef = useRef(null);

  const handleAccordionChange = () => {
    setExpanded(!expanded);
  };

  const handleModelSelect = (model) => {
    onSelectModel(model);
    setExpanded(false);
  };

  return (
    <Accordion expanded={expanded} onChange={handleAccordionChange} ref={accordionRef}  style={{ maxWidth: '600px' }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <Typography variant="h5">{title}</Typography>
    
      </AccordionSummary>
      <AccordionDetails>
        <Typography>{description}</Typography>
      </AccordionDetails>
      <CardContent>
        {models.map((model) => (
          <ModelCard key={model.id} title={model.title} description={model.description} onClick={() => handleModelSelect(model)} />
        ))}
      </CardContent>
    </Accordion>
  );
};

// Rest of the components and code remain the same...


const ModelCard = ({ title, description, onClick }) => {
  return (
    <Card onClick={onClick} style={{ cursor: 'pointer', margin: '10px 0' }}>
      <CardContent>
        <Typography variant="h6">{title}</Typography>
        <Typography variant="body2">{description}</Typography>
      </CardContent>
    </Card>
  );
};

const MLCardsPage = () => {
  const initialModelSelectionCards = [
    {
      id: 'regression',
      title: 'Regression',
      description: 'Model for predicting continuous numeric values.',
      subModels: [
        {
          id: 'linear-regression',
          title: 'Linear Regression',
          description: 'Model for predicting continuous numeric values with a linear relationship.',
        },
        {
            id: 'Progressive-regression',
            title: 'Progressive Regression',
            description: 'Model for predicting continuous numeric values with a linear relationship.',
          },
          
        // More sub-models for regression
      ],
    },
    {
      id: 'classification',
      title: 'Classification',
      description: 'Model for predicting categorical values.',
      subModels: [
        {
          id: 'logistic-regression',
          title: 'Logistic Regression',
          description: 'Model for predicting categorical values using a logistic function.',
        },
        {
            id: 'KNN Classification',
            title: 'KNN Classification',
            description: 'Model for predicting categorical values using a logistic function.',
          },
          
        // More sub-models for classification
      ],
    },
  ];

  const [selectedModel, setSelectedModel] = useState(null);

  const handleModelSelect = (model) => {
    setSelectedModel(model);
  };

  return (
    <div className="app-container">
        <Header/>
        <div className='topbuttons'>

<div className='backbutton'>
  <Link to="/mlmodels">
    <Button size="medium" variant="contained"
      tabIndex={-1}
      sx={{
        backgroundColor: 'black',
        color: 'white',
        fontWeight: 'bold',
        fontSize: '18px',
        borderRadius: '10px',
        '&:hover': {
          backgroundColor: 'darkgray',
          color: 'black',
        },
      }}><ArrowBackIcon />Back</Button>
  </Link>
</div>

</div>

<div className='accordions-group'>

      <div className='accordions'>

        
      {initialModelSelectionCards.map((accordion) => (
        <ModelAccordion
          key={accordion.id}
          title={accordion.title}
          description={accordion.description}
          models={accordion.subModels}
          onSelectModel={handleModelSelect}
        />
      ))}
      {selectedModel && (
        <div>
          <Typography variant="h6">Selected Model:</Typography>
          <ModelCard title={selectedModel.title} description={selectedModel.description} />
        </div>
      )}
      </div>

</div>




    </div>


  );
};

export default MLCardsPage;
